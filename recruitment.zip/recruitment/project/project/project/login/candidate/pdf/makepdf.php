<?php
session_start();
require("fpdf.php");

$hostname = "localhost";
$db = "recruitment";
$Username = "root";
$Password = "";
$conn = mysqli_connect($hostname,$Username,$Password,$db) Or DIE ("unable to connect database");

if( isset($_SESSION['userid'] ) ) {

    $id =$_SESSION['userid'];
   }
   

if(isset($_POST['generate'])){

    $pdf = new FPDF();

          $pdf->AddPage();
          $pdf->SetFont("Arial","B",19);
    $candidate ="SELECT * FROM `candidate` WHERE candidate_id  =  '$id'";
    $result2 = $conn->query( $candidate );


     if ($result2->num_rows > 0) {
       // output data of each row
       while($row = $result2->fetch_assoc()) {

         /* $name = $row['name']; 
          $last = $row['last']; 
          $gender = $row['gender']; 
          $email = $row['email'];  
          $phone = $row ['phone'];*/
          $pdf->cell(50,10,"Firstname",1,0);
          $pdf->cell(50,10,$row['name'],1,1);
  
          $pdf->cell(50,10,"Lastname",1,0);
          $pdf->cell(50,10,$row['last'],1,1);
          
          $pdf->cell(50,10,"Gender",1,0);
          $pdf->cell(50,10,$row['gender'],1,1);
  
             
          $pdf->cell(50,10,"phone",1,0);
          $pdf->cell(50,10,$row ['phone'],1,1);
  
          $pdf->cell(50,10,"Email",1,0);
          $pdf->cell(70,10,$row['email'],1,1);




       }}
             

       $education ="SELECT * FROM `education`   WHERE candidate_id  = '$id'";
       $result3 = $conn->query($education);
       if ($result3->num_rows > 0) {
           while($row = $result3->fetch_assoc()) {

                $pdf->cell(70,10,"Qualification Name",1,0);
                $pdf->cell(50,10, $row['name'],1,1);

                $pdf->cell(50,10,"Institution",1,0);
                $pdf->cell(50,10,$row['institution'],1,1);
        
                $pdf->cell(70,10,"Completion Date",1,0);
                $pdf->cell(50,10,$row['date'],1,1);

                $pdf->cell(70,10,"Project Name",1,0);
                 $pdf->cell(50,10,$row['project_name'],1,1);

              $pdf->cell(70,10,"Project Description",1,0);
              $pdf->cell(50,10,$row['description'],1,1);

              
                


           }}

           
           $experiance ="SELECT * FROM `experiance`  WHERE candidate_id  =  '$id'";
           $result4 = $conn->query($experiance);
           if ($result4->num_rows > 0) {
    // output data of each row
          while($row = $result4->fetch_assoc()) {


              

              $pdf->cell(50,10,"Job Title",1,0);
              $pdf->cell(50,10,$row['title'],1,1);
              
              $pdf->cell(50,10,"Company",1,0);
              $pdf->cell(70,10,$row['name'],1,1);
      
              $pdf->cell(50,10,"Start Date",1,0);
              $pdf->cell(50,10,$row['Sdate'],1,1);
      
              
              $pdf->cell(50,10,"End Date",1,0);
              $pdf->cell(50,10,$row['Edate'],1,1);
      
              $pdf->cell(70,10,"Job Description",1,0);
              $pdf->cell(50,10,$row['description'],1,1);
            
              $pdf->cell(70,10,"Job Acievements ",1,0);
              $pdf->cell(50,10,$row['achievements'],1,1);




          }}
       

        

       /* $pdf->cell(50,10,"Firstname",1,0);
        $pdf->cell(50,10,$name,1,1);

        $pdf->cell(50,10,"Lastname",1,0);
        $pdf->cell(50,10,$last,1,1);
        
        $pdf->cell(50,10,"Gender",1,0);
        $pdf->cell(50,10,$gender,1,1);

           
        $pdf->cell(50,10,"phone",1,0);
        $pdf->cell(50,10,$phone,1,1);

        $pdf->cell(50,10,"Email",1,0);
        $pdf->cell(50,10,$email,1,1);*/
       
      

       
        
        

        

    


    $pdf->Output();
}










?>