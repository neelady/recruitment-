<?php

session_start();

$hostname = "localhost";
$db = "recruitment";
$Username = "root";
$Password = "";
$conn = mysqli_connect($hostname,$Username,$Password,$db) Or DIE ("unable to connect database");


if( isset($_SESSION['userid'] ) ) {

  $id =$_SESSION['userid'];
 }
 


?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>job</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/simple-sidebar.css" rel="stylesheet">
  <link href="./main.css" rel="stylesheet"></head>
  
  <style>
* {
  box-sizing: border-box;
}

.child {
  list-style-type: none;
  padding: 0;
  margin: 0;
}

.child {
  border: 1px solid #ddd;
  margin-top: -1px; /* Prevent double borders */
  background-color: #f6f6f6;
  padding: 12px;
} 
.center {



}
h4{
 color: #0d6efd;
 background-color:#f6f6f6 ;


}

</style>
  

</head>

<body>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading"> Fast Recruitment </div>
      <div class="list-group list-group-flush">
        <a href="index.php" class="list-group-item list-group-item-action bg-light">Dashboard</a>
        <a href="applications.php" class="list-group-item list-group-item-action bg-light">Applications</a>
        <a href="jobs.php" class="list-group-item list-group-item-action bg-light">job</a>
        <a href="profile.php" class="list-group-item list-group-item-action bg-light">Profile</a>
   
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <button class="btn btn-primary" id="menu-toggle">Toggle Menu</button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Link</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Account
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Action</a>
                <a class="dropdown-item" href="#">Another action</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="logout.php">logout</a>
              </div>
            </li>
          </ul>
        </div>
      </nav>

  <!-- paste the page content  -->

   <div class = "center">
 <form id="regForm" action="pdf/makepdf.php" method = "post">
 <div class = "center">
   <h4>Personal:</h4>
 
     <?php
 
     $candidate ="SELECT * FROM `candidate` WHERE candidate_id  =  '$id'";
     $result2 = $conn->query( $candidate );
 
      if ($result2->num_rows > 0) {
        // output data of each row
        while($row = $result2->fetch_assoc()) {
     
     ?>
        <div class="child">
       <?php echo $row ['name']; ?><br>
       <?php echo $row ['last']; ?><br>
       <?php echo $row ['gender']; ?><br> 
       <?php echo $row ['email']; ?><br> 
       <?php echo $row ['phone']; ?><br>
       <?php $id_num = $row ['id']; ?><br> 
     
        </div>
       <?php
        }}
 
 
       ?>
 
  
  
   <h4>Education:</h4>
   <?php
 
       $education ="SELECT * FROM `education`   WHERE candidate_id  = '$id'";
       $result3 = $conn->query($education);
       if ($result3->num_rows > 0) {
    // output data of each row
         while($row = $result3->fetch_assoc()) {
 
     ?>
       <div class="child">
       <?php echo $row ['name']; ?><br>
       <?php echo $row ['institution']; ?><br>
       <?php echo $row ['date']; ?><br> 
       <?php echo $row ['project_name']; ?><br> 
       <?php echo $row ['description']; ?><br> 
   
         </div>
       <?php
        }
       }
       ?>
     
   </div>
   <h4>Experiance:</h4>
 
        
     <?php
 
    $experiance ="SELECT * FROM `experiance`  WHERE candidate_id  =  '$id'";
     $result4 = $conn->query($experiance);
     if ($result4->num_rows > 0) {
    // output data of each row
    while($row = $result4->fetch_assoc()) {
 
     ?>
        <div class="child">
         
           <?php echo $row ['title']; ?><br>
           <?php echo $row ['name']; ?><br>
           <?php echo $row ['Sdate']; ?><br> 
           <?php echo $row ['Edate']; ?><br> 
           <?php echo $row ['description']; ?><br> 
           <?php echo $row ['achievements']; ?><br> 
      
         </div>
    <?php
    }}
 
 
    ?>
 
   
   
  
   <h4>Attachments:</h4>
 
      
   <?php
 
   $attachment ="SELECT DISTINCT * FROM `attachment`  WHERE candidate_id  = '$id'";
   $result5 = $conn->query($attachment);
   if ($result5 ->num_rows > 0) {
    // output data of each row
   while($row = $result5->fetch_assoc()) {
 
  ?>
      <div class="child">
        <?php echo $row ['name']; ?><br>
       
      </div>
   <?php
    }}
   ?>
     <h4>Qr code :</h4>
     <div class="qrframe" style="border:2px solid black; width:150px; height:150px;">
							<?php echo '<img src="temp/'.$id_num.'.png" style="width:150px; height:150px;"><br>'; ?>
					</div><br> 
      <button name = "generate" class="btn btn-primary">download pdf</button>
  </div>
 </form>
 
 
  <!-- /#page-content-wrapper -->

  </div>
  <!-- /#wrapper -->
  

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>

</body>

</html>
