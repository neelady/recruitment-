

<?php

session_start();

$hostname = "localhost";
$db = "recruitment";
$Username = "root";
$Password = "";
$conn = mysqli_connect($hostname,$Username,$Password,$db) Or DIE ("unable to connect database");

if( isset($_SESSION['userid'] ) ) {

  $id =$_SESSION['userid'];
 
 }

$query = "SELECT *
FROM job j
INNER JOIN application a ON a.job_id = j.id
INNER JOIN candidate c ON a.candidate_id = c.candidate_id
where c.candidate_id = '$id'";
$result = mysqli_query($conn,$query);



?>


<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Applications</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/simple-sidebar.css" rel="stylesheet">

</head>

<body>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading"> Fast Recruitment </div>
      <div class="list-group list-group-flush">
        <a href="index.php" class="list-group-item list-group-item-action bg-light">Dashboard</a>
        <a href="applications.php" class="list-group-item list-group-item-action bg-light">Applications</a>
        <a href="jobs.php" class="list-group-item list-group-item-action bg-light">job</a>
        <a href="profile.php" class="list-group-item list-group-item-action bg-light">Profile</a>
        <a href="viewprofile.php" class="list-group-item list-group-item-action bg-light">View Profile</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <button class="btn btn-primary" id="menu-toggle">Toggle Menu</button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Link</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Account
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Action</a>
                <a class="dropdown-item" href="#">Another action</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">logout</a>
              </div>
            </li>
          </ul>
        </div>
      </nav>
      <!-- paste here -->

      
  <?php

  while($rows = mysqli_fetch_array($result))
 {

?>
<form action = "applications.php" method ="post" role = "form" >
<ul>
<li>
<?php echo $rows ['title']; ?><br>
<?php echo $rows ['type']; ?><br>
<?php echo $rows ['date']; ?><br> 
<?php echo $rows ['description']; ?><br> 
<?php echo $rows ['requirements']; ?><br> 
<?php echo $rows ['salary']; ?><br>
<?php  $job_id = $rows ['id'] ; ?>
<button class="btn btn-primary" name = "withdraw">Withdraw Application</button>

</li>

</ul>
</form>
<?php
}
?>
      
      <!-- /#page-content-wrapper -->
      
      <?php


if(isset($_POST['withdraw']))
{

    $sql = "DELETE 
    FROM application 
    where candidate_id = '$id'";

   if (mysqli_query($conn, $sql)) {
      echo "application  successfully withdrawen";
      header("Location:applications.php");
    } else {
       echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }

 }


 if(isset($_POST['status']))
 {
 
     $sql = "SELECT status FROM `application` 
     where c.candidate_id = '$id'";
 
    if (mysqli_query($conn, $sql)) {
       echo "application  successfully withdrawen";
       header("Location:applications.php");
     } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
   }
 
  }





 ?>


      

  </div>
  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>

</body>

</html>
