
<?php
 
 session_start();


 //include('libs/phpqrcode/qrlib.php');
 include("profile_cl.php");

 $profile = new PDO("mysql:host=localhost;dbname=recruitment","root","");

 if( isset($_SESSION['userid'] ) ) {

	  $id =$_SESSION['userid'];
  
 }

  //echo $id;

   if( isset($_SESSION['email'] ) ) {

    $email =$_SESSION['email'];
   }
   
   //echo $email;

   //$ID = $profile->prepare("SELECT candidate_id from candidate where email = '$email'");
          ///echo $id;
   $candidate = new personal();
 if(isset($_POST['person']))
 {

   $candidate->name = $_POST['name'];
   $candidate->surname= $_POST['surname'];
   $candidate->gender  = $_POST['gender'];
   $candidate->idnum  = $_POST['id'];
   if(isset($_POST['dob'])){
         
    $candidate->dob  = $_POST['dob'];
   }
   
   $candidate->phone = $_POST['phone'];

           //QRcode
        


     

     

    
   
   if($candidate->checkfield() == true){


		//echo ' <script  type = "text/javascript">  alert("All field  required") </script>';
      echo "All fields  required";  



	   }elseif($candidate->checkNames() == true){
			  
		echo ' <script  type = "text/javascript">  alert("Name and Surname Must Contain Only Letters") </script>';
        

		
	   }else{

      $sql = "UPDATE `candidate` SET `name`=?,`last`=?,`gender`=?,`dob`=?,`phone`=?,`id`=? WHERE email = '$email'";
          $stmt = $profile->prepare($sql);
          $stmt->bindParam(1,$candidate->name);
          $stmt->bindParam(2,$candidate->surname);
          $stmt->bindParam(3,$candidate->gender);
          $stmt->bindParam(4,$candidate->dob);
          $stmt->bindParam(5,$candidate->phone);
          $stmt->bindParam(6,$candidate->idnum);
          $stmt->execute();
  
         // header("Location:userprofile.php");
  
  
         }






 }

   $edu = new education();
 if(isset($_POST['edu']))
 {
     
      $edu->Qname = $_POST['Qname'];
    
    
      $edu->Iname = $_POST['Iname'];
   
    
      $edu->date  = $_POST['Date'];

    
    
      $edu->pName = $_POST['Pname'];

     
     
      $edu->pDesc =  $_POST['desc'];

    
      
  
  

     if($edu->checkfield() == true){


		   echo '<script  type = "text/javascript">  alert("All field  required") </script>';
        



	
     }else{
            
          //$id2 =$profile->prepare("SELECT candidate_id FROM candidate where email = '$email'");
          $sql = "INSERT INTO `education`( `name`, `institution`, `date`, `project_name`, `description`, `candidate_id`) VALUES (?,?,?,?,?,?)";
          $stmt = $profile->prepare($sql);
          $stmt->bindParam(1, $edu->Qname);
          $stmt->bindParam(2, $edu->Iname);
          $stmt->bindParam(3, $edu->date);
          $stmt->bindParam(4, $edu->pName);
          $stmt->bindParam(5, $edu->pDesc);
          $stmt->bindParam(6,	$id);
           $stmt->execute();

         }







}

 $exp = new experiance();
 if(isset($_POST['exp']))
 {

  $exp->title = $_POST['title'];
  $exp->company = $_POST['company'];
  $exp->Sdate   = $_POST['Sdate'];
  $exp->Edate   = $_POST['Edate'];
  $exp->Jdesc  = $_POST['Jdesc'];
  $exp->Adesc  = $_POST['Adesc'];

    

   
    
   if($exp->checkfield() == true){


		echo ' <script  type = "text/javascript">  alert("All field  required") </script>';
        



	
         }else{
          //$id = $profile->prepare("SELECT id from candidate where email = '$email'");
          $sql = "INSERT INTO `experiance`( `title`, `name`, `Sdate`, `Edate`, `description`, `achievements`, `candidate_id`) VALUES (?,?,?,?,?,?,?)";
          $stmt = $profile->prepare($sql);
          $stmt->bindParam(1, $exp->title);
          $stmt->bindParam(2, $exp->company);
          $stmt->bindParam(3, $exp->Sdate );
          $stmt->bindParam(4, $exp->Edate);
          $stmt->bindParam(5, $exp->Jdesc);
          $stmt->bindParam(6, $exp->Adesc);
          $stmt->bindParam(7, $id);
           $stmt->execute();

         }









 }

    $attch = new attachement();
 if(isset($_POST['attach']))
 {
  $attch->filename = $_POST['filename'];
  
   $attch->myfile = file_get_contents($_FILES['myfile']['tmp_name']);
   $attch->fileError= $_FILES['myfile']['error'];
   $attch->name = $_FILES['myfile']['name'];
  
   
      if($attch->checkfile()==true){

		  echo ' <script  type = "text/javascript">  alert("Error occured while uploading your file") </script>';



	   }else{

      $sql = "INSERT INTO `attachment`(`name`,`doc`,`candidate_id`) VALUES (?,?,?)";
      $stmt = $profile->prepare($sql);
      $stmt->bindParam(1, $attch->filename);
      $stmt->bindParam(2, $attch->myfile);
      $stmt->bindParam(3,$id);
      $stmt->execute();


     }
         
       


 }

   //require_once'phpqrcode/qrlib.php';
 //include('libs/phpqrcode/qrlib.php');
 /*$tempDir  = 'temp/'; 
 $filename =  $tempDir.$candidate->idnum.".png";
 $codeContents = ' Name: '.urlencode($candidate->name)
  .' Surname: '.urlencode($candidate->surname)
  .' Gender '.urlencode ($candidate->gender)
  .' Qualification: '.urlencode($edu->Qname)
  .' Institution: '.urlencode($edu->Iname)
  .'Job Title: '.urlencode($exp->title )
  .'&Company= '.urlencode($exp->company);
   QRcode::png($codeContents,$filename,QR_ECLEVEL_L, 5);*/

?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>profile</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/simple-sidebar.css" rel="stylesheet">
 
  <link href="./main.css" rel="stylesheet"></head>
  

</head>


<body>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading"> Fast Recruitment </div>
      <div class="list-group list-group-flush">
        <a href="index.php" class="list-group-item list-group-item-action bg-light">Dashboard</a>
        <a href="applications.php" class="list-group-item list-group-item-action bg-light">Applications</a>
        <a href="jobs.php" class="list-group-item list-group-item-action bg-light">job</a>
        <a href="profile.php" class="list-group-item list-group-item-action bg-light">Profile</a>
        <a href="viewprofile.php" class="list-group-item list-group-item-action bg-light">View Profile</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <button class="btn btn-primary" id="menu-toggle">Toggle Menu</button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Link</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Account
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Action</a>
                <a class="dropdown-item" href="#">Another action</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="logout.php">logout</a>
              </div>
            </li>
          </ul>
        </div>
      </nav>
      <div id="myBtnContainer">
      <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
        <li class="nav-item">
            <a role="tab" class="nav-link active" onclick="filterSelection('Personal')  id="tab-0" data-toggle="tab" href="#tab-content-0">
                <span>Personal</span>
            </a>
        </li>
        <li class="nav-item">
            <a role="tab" class="nav-link"​ onclick="filterSelection('Education')  id="tab-1" data-toggle="tab" href="#tab-content-1">
                <span>Education</span>
            </a>
        </li>
        <li class="nav-item">
            <a role="tab" class="nav-link"  onclick="filterSelection('Experince')     id="tab-2" data-toggle="tab" href="#tab-content-2">
                <span>Experince</span>
            </a>
        </li>
        <li class="nav-item">
            <a role="tab" class="nav-link"  onclick="filterSelection('Attachments')    id="tab-2" data-toggle="tab" href="#tab-content-3">
                <span>Attachments</span>
            </a>
        </li>
    </ul>
</div>
    <div class="container">
    <div class="tab-content">
        <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                <div class="filterDiv Personal"><h5 class="card-title">Personal Info</h5>
                    <form class="" method = "post" action = "profile.php">

                        <div class="position-relative form-group"><label for="exampleAddress" class=""> First  Name</label><input name="name" id="exampleAddress" placeholder="First Name"    type="text" class="form-control"></div>
                        <div class="position-relative form-group"><label for="exampleAddress2" class="">Second Name</label><input  name="surname" id="exampleAddress2" placeholder="Last Name" type="text" class="form-control"></div>
                        
                        <div class="position-relative form-group"><label for="exampleAddress2" class="">Id</label><input  name="id" id="exampleAddress2" placeholder="Identitiy Number" type="text" class="form-control"></div>
                        <div class="form-check">
                        <input class="form-check-input" type="radio" name="gender" id="flexRadioDefault1">
                         <label class="form-check-label" for="flexRadioDefault1">Female</label>
                         </div>
                         <div class="form-check">
                         <input class="form-check-input" type="radio" name="gender" id="flexRadioDefault2" checked>
                         <label class="form-check-label" for="flexRadioDefault2">Male</label>
                         </div>

                        </div>
                        <div class="position-relative form-group"><label for="exampleAddress" class="">Date</label><input    name="dob" id="exampleAddress" placeholder="Date of Birth"    type="date" class="form-control"></div>
                        <div class="position-relative form-group"><label for="exampleAddress2" class="">Phone</label><input  name=" phone" id="exampleAddress2" placeholder="Phone Number" type="text" class="form-control"></div>
                      
                        <button name ="person" class="mt-2 btn btn-primary">Submit</button>
                    </form>
                </div>      
             </div>

        <div class="tab-pane tabs-animation fade" id="tab-content-1" role="tabpanel">
                <div class="filterDiv Education"><h5 class="card-title">Education</h5>
                    <form class="" method = "post" action = "profile.php"  >
                        <div class="position-relative form-group"><label for="exampleAddress" class=""> Qualification Name</label><input name="Qname" id="exampleAddress"  placeholder="Qualification Name"    type="text" class="form-control"></div>
                        <div class="position-relative form-group"><label for="exampleAddress2" class=""> Institution Name</label><input  name="Iname" id="exampleAddress2" placeholder="Institution Name"     type="text" class="form-control"></div>
                        <div class="position-relative form-group"><label for="exampleAddress2" class=""> Completion Date</label><input  name="Date" id="exampleAddress2"  placeholder="Date"   type="date" class="form-control"></div>
                        <span class="input-group-text">Tell us about your final year project</span>
                        <div class="position-relative form-group"><label for="exampleAddress2" class="">Project Name</label><input  name="Pname" id="exampleAddress2"  placeholder="Name of the project"   type="text" class="form-control"></div>
                        <div class="input-group">
                            <span class="input-group-text">Description</span>
                            <textarea class="form-control" name ="desc" aria-label="With textarea"></textarea>
                          </div>
                          <button  name = "edu"class="mt-2 btn btn-primary">Submit</button>
                    </form>
                </div>
        </div>

          
        <div class="tab-pane tabs-animation fade" id="tab-content-2" role="tabpanel">
                <div class="filterDiv Experiance"><h5 class="card-title">Experiance</h5>
                    <form class="" method = "post" action = "profile.php" >
                        <div class="position-relative form-group"><label for="exampleAddress" class="">Job Title</label><input       name="title" id="exampleAddress"  placeholder="Job Title"    type="text" class="form-control"></div>
                        <div class="position-relative form-group"><label for="exampleAddress2" class=""> Company Name</label><input  name="company" id="exampleAddress2" placeholder="Company Name"     type="text" class="form-control"></div>
                        <div class="position-relative form-group"><label for="exampleAddress2" class=""> Start Date</label><input    name="Sdate" id="exampleAddress2"  placeholder="Start Date"   type="date" class="form-control"></div>
                        <div class="position-relative form-group"><label for="exampleAddress2" class=""> End Date</label><input      name="Edate"   id="exampleAddress2"  placeholder="End Date"   type="date" class="form-control"></div>
                        <div class="input-group">
                            <span class="input-group-text"> Job Description</span>
                            <textarea class="form-control" name ="Jdesc" aria-label="With textarea"></textarea>
                          </div> <br>
                          <div class="input-group">
                            <span class="input-group-text">Achievements</span>
                            <textarea class="form-control" name ="Adesc" aria-label="With textarea"></textarea>
                          </div>
                          <button  name ="exp" class="mt-2 btn btn-primary">Submit</button>
                    </form>
                </div>
        </div>

          
        <div class="tab-pane tabs-animation fade" id="tab-content-3" role="tabpanel">
                <div class="filterDiv Attachments"><h5 class="card-title">Attachments</h5>
                    <form class=""  method = "post" action = "profile.php" enctype="multipart/form-data" >
                        <div class="position-relative form-group">
                            <label for="myfile">Select a file:</label>
                            <input name="filename" id="exampleAddress"  placeholder="File Name" type="text" class="form-control"><br>
                            <input type="file" id="myfile" name="myfile" required><br><br>
                        </div>
                          <button name="attach" class="mt-2 btn btn-primary">Submit</button>
                    </form>
              </div>
        </div>
    </div>
    </div>
    <script type="text/javascript" src="./assets/scripts/main.js"></script>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Menu Toggle Script -->

  <script>
filterSelection("all")
function filterSelection(c) {
  var x, i;
  x = document.getElementsByClassName("filterDiv");
  if (c == "all") c = "";
  for (i = 0; i < x.length; i++) {
    w3RemoveClass(x[i], "show");
    if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "show");
  }
}

function w3AddClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    if (arr1.indexOf(arr2[i]) == -1) {element.className += " " + arr2[i];}
  }
}

function w3RemoveClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    while (arr1.indexOf(arr2[i]) > -1) {
      arr1.splice(arr1.indexOf(arr2[i]), 1);     
    }
  }
  element.className = arr1.join(" ");
}

// Add active class to the current button (highlight it)
var btnContainer = document.getElementById("myBtnContainer");
var btns = btnContainer.getElementsByClassName("nav-link");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function(){
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}
</script>
  


</body>
</html>
