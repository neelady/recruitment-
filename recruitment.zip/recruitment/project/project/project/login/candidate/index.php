<?php


$hostname = "localhost";
 $db = "recruitment";
 $Username = "root";
 $Password = "";
 $conn = mysqli_connect($hostname,$Username,$Password,$db) Or DIE ("unable to connect database");
 session_start();

 if( isset($_SESSION['userid'] ) ) {

    $id =$_SESSION['userid'];

}


 if(isset($_POST['submit']))
 {
    $searchq = $_POST['search'];
    echo'$searchq';
   // $searchq = preg_replace($searchq);
    $query = "SELECT * FROM job WHERE title  = '$searchq' OR type ='$searchq'";
    $query_run = mysqli_query($conn, $query);
    if(mysqli_num_rows($query_run) > 0)
    {
      foreach($query_run as $row)
      {
      ?>
        <div class="form-group mb-3">
        <label for="">Name</label>
        <input type="text" value="<?= $row['title']; ?>" class="form-control">
       </div>
       <div class="form-group mb-3">
       <label for="">type</label>
       <input type="text" value="<?= $row['type']; ?>" class="form-control">
       </div>
       <div class="form-group mb-3">
       <label for="">closing date</label>
       <input type="text" value="<?= $row['date']; ?>" class="form-control">
       </div>
      
       <?php
      }
      }
      else
      {
        echo "No Record Found";
       }
      }
                                   

?>



<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Dashboard</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/simple-sidebar.css" rel="stylesheet">
  <link href="main.css" rel="stylesheet"></head>
  <style>

.table{

    width: 1050px;
    margin-left: auto;
    margin-right: auto;

 }
 
  </style>
</head>

<body>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading"> Fast Recruitment </div>
      <div class="list-group list-group-flush">
        <a href="index.php" class="list-group-item list-group-item-action bg-light">Dashboard</a>
        <a href="applications.php" class="list-group-item list-group-item-action bg-light">Applications</a>
        <a href="jobs.php" class="list-group-item list-group-item-action bg-light">job</a>
        <a href="profile.php" class="list-group-item list-group-item-action bg-light">Profile</a>
        <a href="viewprofile.php" class="list-group-item list-group-item-action bg-light">View Profile</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <button class="btn btn-primary" id="menu-toggle">Toggle Menu</button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            
            <li class="nav-item">
            <div class="input-group">
            <input type="search" class="form-control rounded" placeholder="Search" aria-label="Search"
            aria-describedby="search-addon" />
         <button type="button" class="btn btn-outline-primary">search</button>
        </div>
            
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Account
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Account</a>
                <a class="dropdown-item" href="#">Settings</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="logout.php">logout</a>
              </div>
            </li>
          </ul>
        </div>
      </nav>


<?php
$sql = "SELECT Count(status) as num
FROM application a, candidate d
WHERE a.candidate_id =  '$id'";
$result2 = mysqli_query($conn,$sql);
 while($row= mysqli_fetch_array($result2))
  {
  
?>





      <div class="row">
                            <div class="col-md-6 col-xl-4">
                                <div class="card mb-3 widget-content bg-midnight-bloom">
                                    <div class="widget-content-wrapper text-white">
                                        <div class="widget-content-left">
                                            <div class="widget-heading">Total Applications</div>
                                            <div class="widget-subheading">Last year expenses</div>
                                        </div>
                                        <div class="widget-content-right">
                                            <div class="widget-numbers text-white"><span><?php echo $row['num'];?></span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
 }
 $sql1 = "SELECT Count(id) as number
            FROM job";
$result3 = mysqli_query($conn,$sql1);
while($row= mysqli_fetch_array($result3))
                                       
{
?>
                                      




                                   

  
                                

                            <div class="col-md-6 col-xl-4">
                                <div class="card mb-3 widget-content bg-arielle-smile">
                                    <div class="widget-content-wrapper text-white">
                                        <div class="widget-content-left">
                                            <div class="widget-heading">Total jobs</div>
                                            <div class="widget-subheading">Total Clients Profit</div>
                                        </div>
                                        <div class="widget-content-right">
                                            <div class="widget-numbers text-white"><span><?php echo $row['number'];?></span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
 }
 $sql2 = "SELECT Count(saved) as saved
            FROM application";
$result4 = mysqli_query($conn,$sql2);
while($row= mysqli_fetch_array($result4))
                                       
{
?>
   

                            <div class="col-md-6 col-xl-4">
                                <div class="card mb-3 widget-content bg-grow-early">
                                    <div class="widget-content-wrapper text-white">
                                        <div class="widget-content-left">
                                            <div class="widget-heading">Total Saved jobs </div>
                                            <div class="widget-subheading">People Interested</div>
                                        </div>
                                        <div class="widget-content-right">
                                            <div class="widget-numbers text-white"><span><?php echo $row['saved'];?></span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                                        }
                                      ?>

    <!-- /#page-content-wrapper -->

    <table class="table"     > 
 <thead>
 <tr>
     <th  scope="col">#</th>
     <th scope="col">Name</th>
     <th  scope="col">Closing Dates</th>
     <th  scope="col">Status</th>
     <th scope="col">Actions</th>
 </tr>
 </thead>

    <?php


$query2 = "SELECT DISTINCT j.id AS id ,j.title AS title ,j.date AS date ,j.type AS type ,a.status AS status FROM job j, application a , candidate c WHERE a.job_id = j.id AND a.candidate_id = '$id'";
$result = mysqli_query($conn,$query2);
 while($rows = mysqli_fetch_array($result))
  {
  
?>
                                            <tbody>
                                            <tr>
                                                <td scope="row"class="table-info" >#<?php echo $rows['id'];?></td>
                                                <td class="table-primary"><?php echo $rows['title'];?></td>
                                                <td class="table-info"><?php echo $rows['date'];?></td>
                                                <td class="table-primary"><?php echo $rows['status'];?></td>
                                                <td class="table-info"><?php echo $rows['type'];?></td>
                                            </tr>
                                            <?php
                                        }
                                      ?>
                                            </tbody>
                                        </table>
                                 
































  </div>
  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>

</body>

</html>
