<?php

  


class personal{

    public $name;
    public $surname;
    public $gender;
    public $idnum;
    Public $phone;
    public $dob;
    
    public  function checkfield()
    {
      if(empty($this->name) || empty($this->surname)|| empty($this->gender)|| empty($this->phone)|| empty($this->dob)|| empty($this->idnum) )
      {
   
         return true;
   
      }
     
       return false;
   
   
    }

    public function checkNames()
    {
 
 
     if (!preg_match("/^[a-zA-Z-' ]*$/",$this->name) || !preg_match("/^[a-zA-Z-' ]*$/",$this->surname)) {
         return true;
       }
 
     return false;
 
    }


    
    

}

class education {


    public $pName;
    public $pDesc;
    public $Iname;
    public $Qname;
    public $date;

    public  function checkfield()
    {
      if(  empty($this->pName) || empty($this->pDesc)|| empty($this->Iname)|| empty($this->Qname)|| empty($this->date))
   
         return true;
   
      
     
       return false;
   
   
    }
    






}

class experiance {

    public $title;
    public $company;
    public $Sdate;
    public $Edate;
    public $Jdesc;
    public $Adesc;

    public  function checkfield()
    {
      if( empty ($this->title)|| empty($this->company) || empty($this->Sdate)|| empty($this->Edate)|| empty($this->Jdesc)|| empty($this->Adesc))
      {
   
         return true;
   
      }
     
       return false;
   
   
    }
    


}

class attachement{
    
    public $filename;
    public $name;
    public $myfile;
    public $fileError;

    
    public function checkfile()
    {
           
      if($this->fileError === 0){

          move_uploaded_file($this->myfile,"file".$this->name);
          return false;


      }else{

        return true;




      }


    
    
   }



}










?>