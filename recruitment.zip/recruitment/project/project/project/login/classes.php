<?php

  //session_start();

 
class database{


 
     
    protected $hostname = "localhost";
    protected $db = "recruitment";
    protected $Username = "root";
    protected $Password = "";
     
      protected function conn(){
  
          $conn = mysqli_connect($this->hostname,$this->Username,$this->Password,$this->db) Or DIE ("unable to connect database");
  
  
          return $conn;
  
      }
    
  
  }
  

class account extends database {


  public $email;
  public $password;
  public $retypePassword;
   

  public function checkEmpty()
  {

      if ( empty($this->email)|| empty($this->password)|| empty($this->retypePasswword)){


           return true;


      }
   

      return false;



  }

  public function CheckEmail ()
  {


    
    if (!filter_var($this->email, FILTER_VALIDATE_EMAIL)) {
      return true;
      }else
      {
      
        return false;
      }

  }




  public function checkMatch()
  {

      if($this->password != $this->retypePassword)
      {


        return true;

      }

    return false;

  }


    public function checkAccount()

    {
        $sql = "SELECT email From candidate WHERE email = '".$this->email."';";
        $result = $this->conn()->query($sql);

         

         $num_rows = $result->num_rows;
          if($num_rows>0)
          {

            return true;
            

          }
         return false;




    }



    public function checkAccountM()

    {
        $sql = "SELECT email From employer WHERE email = '".$this->email."';";
        $result = $this->conn()->query($sql);

         

         $num_rows = $result->num_rows;
          if($num_rows>0)
          {

            return true;
            

          }
         return false;




    }



}



class login extends database
{


    public $email;
    public $password;
    
   public  function checkfield()
  {
     if( empty ($this->email)|| empty($this->password))
     {

        return true;

     }
    
      return false;


   }
  


  public function processLogin(){

  $sql = "SELECT * FROM candidate WHERE email = '".$this->email."' AND password = '".$this->password."'; ";
  $result = $this->conn()->query($sql);
  $row =  $result->fetch_assoc();

  if( $row['email'] == $this->email && $row['password'] == $this->password )
  { 
    session_start();
    $_SESSION['userid'] = $row['candidate_id'];
    $_SESSION['email'] = $row['email'];
      return true;
         

  }
  else {

   
    return false;

  }
  }

  public function processLoginM(){

    $sql = "SELECT * FROM employer WHERE email = '".$this->email."' AND password = '".$this->password."'; ";
    $result = $this->conn()->query($sql);
    $row =  $result->fetch_assoc();
  
    if( $row['email'] == $this->email && $row['password'] == $this->password )
    {
      $_SESSION['userid2'] = $row['id'];
      $_SESSION['email2']  = $row['email'];
        return true;
           
  
    }
    else {
  
     
      return false;
  
    }
   
  
  
 }


}















?>

