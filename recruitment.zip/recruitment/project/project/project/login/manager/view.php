
<?php
session_start();

$hostname = "localhost";
$db = "recruitment";
$Username = "root";
$Password = "";
$conn = mysqli_connect($hostname,$Username,$Password,$db) Or DIE ("unable to connect database");


if( isset($_SESSION['userid2'] ) ) {

	$id =$_SESSION['userid2'];

}

?>

<!Doctype html>

<html lang = "en">
<head>
  <title> job </title>
     <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">

<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

.navbar {
  overflow: hidden;
  background-color: #333; 
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.subnav {
  float: left;
  overflow: hidden;
}

.subnav .subnavbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .subnav:hover .subnavbtn {
  background-color: red;
}

.subnav-content {
  display: none;
  position: absolute;
  left: 0;
  background-color: red;
  width: 100%;
  z-index: 1;
}

.subnav-content a {
  float: left;
  color: white;
  text-decoration: none;
}

.subnav-content a:hover {
  background-color: #eee;
  color: black;
}

.subnav:hover .subnav-content {
  display: block;
}

/*  */
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}
.title {
  color: grey;
  font-size: 18px;
}

</style>
</head>

<body>

  <header>

  <div class="navbar">
  <div class="subnav">
    <button class="subnavbtn">Account<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="create.php">profile</a>
      <a href="view.php">view profile</a>
      <a href="#team">settings</a>
      <a href="logout.php">logout</a>
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn">Applications<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="candidates.php">All applications</a>
      <a href="approve.php">Approved Applications</a>
     
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn">Job<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="job.php">create post</a>
      <a href="viewjob.php">view job</a>
    </div>
  </div>
  <a href="reports.php">Reports</a>
</div>

  </header>
  

  <div class = "center">
 <form id="regForm" action="pdf/makepdf.php" method = "post">
 
 
 
     <?php
 
     $employer ="SELECT * FROM `employer` WHERE id  =  '$id'";
     $result2 = $conn->query($employer);
 
      if ($result2->num_rows > 0) {
        // output data of each row
        while($row = $result2->fetch_assoc()) {
     
     ?>
      <div class="card">
      <img src="images/profile.png" alt="" style="width:100%">
      <h1><?php echo $row ['name']; ?>   <?php echo $row ['last']; ?></h1>
      <p class="title"><?php echo $row ['position']; ?></p>
       <?php echo $row ['email']; ?><br> 
       <?php $id_num = $row ['id']; ?><br> 
     
        </div>
       <?php
        }}
 
 
       ?>
       </div>
 </form>
 
</body>




</html>