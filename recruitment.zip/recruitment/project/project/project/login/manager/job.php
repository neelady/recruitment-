<?php
session_start();
include("job_cl.php");

if( isset($_SESSION['userid2'] ) ) {

	$id =$_SESSION['userid2'];
}
 
 if( isset($_POST['post']))
{

  $job  = new job();
  $job->title  = $_POST['title'];
  $job->type   = $_POST['type'];
  $job->sal    = $_POST['sal'];
  $job->date   = $_POST['date'];
  $job->desc   = $_POST['desc'];

  if( isset($_SESSION['userid2'] ) ) {

    $job->emp_id  = $_SESSION['userid2'];
    
  }
  
  $job->requirements  = $_POST['require'];


   $job->insert();
   


}


?>

<!Doctype html>

<html lang = "en">
<head>
  <title>job</title>
     <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">

<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}
* {
  box-sizing: border-box;
}
.navbar {
  overflow: hidden;
  background-color: #333; 
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.subnav {
  float: left;
  overflow: hidden;
}

.subnav .subnavbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .subnav:hover .subnavbtn {
  background-color: red;
}

.subnav-content {
  display: none;
  position: absolute;
  left: 0;
  background-color: red;
  width: 100%;
  z-index: 1;
}

.subnav-content a {
  float: left;
  color: white;
  text-decoration: none;
}

.subnav-content a:hover {
  background-color: #eee;
  color: black;
}

.subnav:hover .subnav-content {
  display: block;
}
/* form */
.container {
  padding: 16px;
  background-color: white;
}

/* Full-width input fields */
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text],input[type=date], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 50px;
}
</style>







</head>

<body>

<header>
<div class="navbar">
  <div class="subnav">
    <button class="subnavbtn">Account<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="create.php">profile</a>
      <a href="view.php">view profile</a>
      <a href="#team">settings</a>
      <a href="logout.php">logout</a>
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn">Applications<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="candidates.php">All applications</a>
      <a href="approve.php">Approved Applications</a>
     
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn">Job<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="job.php">create post</a>
      <a href="viewjob.php">view job</a>
    </div>
  </div>
  <a href="reports.php">Reports</a>
</div>

</header>



<div class="container">
  <form  action="job.php" method ="POST" >
    <label for="fname">Title</label>
    <input type="text" id="fname" name ="title" placeholder="Job Title">

    <label for="lname">Salary</label>
    <input type="text" id="lname" name ="sal" placeholder="Your last name..">

    <label for="lname">Closing date </label>
    <input type="date" id="lname" name ="date" placeholder="closing date"><br>
 
    <label for="country">Job Type</label>
    <select id="country" name ="type">
     <option value="Permenant">Permenant</option>
     <option value="Contract">Contract</option>
     <option value="Temporary">Temporary</option>
    </select>

    <label for="subject"> Job Description</label>
    <textarea id="subject" name ="desc"   placeholder="Write something.." style="height:200px"></textarea>

    <label for="subject"> Job Requirements</label>
    <textarea id="subject" name ="require" placeholder="Write something.." style="height:200px"></textarea>

    <input type="submit" name ="post" value="Post Job ">
  </form>
</div>












</body>




</html>