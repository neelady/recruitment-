<?php
//session_start();
class database{
  protected $hostname ;
  protected $db ;
  protected $Username ;
  protected $Password ;
   
    protected function conn(){


      $this->hostname = "localhost";
      $this->db = "recruitment";
      $this->Username = "root";
      $this->Password = "";
        $conn = mysqli_connect($this->hostname,$this->Username,$this->Password,$this->db) Or DIE ("unable to connect database");


        return $conn;

    }
  

    protected function pdo(){


      $con2 = new PDO("mysql:host=localhost;dbname=recruitment_system","root","");
  
  
      return $con2;
  
    }
  



}



// echo $id;

if( isset( $_SESSION['email2'] ) ) {

	$email = $_SESSION['email2'];
	
 }
  class job extends database {
  
    
     public  $id;
     public $emp_id;
     public  $title;
     public  $type;
     public  $sal;
     public  $date;
     public  $desc;
     public $requirements;
     


     public  function insert()
     {   
  
          /* $sql = "INSERT INTO job (title, description,type,salary,date,requirements)
           VALUES ('$this->title', '$this->desc', '$this->type','$this->sal','$this->date','$this->require')";
           if ($this->conn()->query($sql) === TRUE) {
            echo "New record created successfully";
           } else {
            echo "Error: " . $sql . "<br>" . $con->error;
            }
        
            $this->conn()->close();*/

            

         
          //$con2 = conn();
          $sql = "INSERT INTO `job`( `title`, `description`, `type`, `salary`, `date`, `requirements`, `emp_id`) VALUES (?,?,?,?,?,?,?)";
            $stmt = $this->pdo()->prepare($sql);
            $stmt->bindParam(1,$this->title);
            $stmt->bindParam(2,$this->desc);
            $stmt->bindParam(3,$this->type);
            $stmt->bindParam(4,$this->sal);
            $stmt->bindParam(5,$this->date);
            $stmt->bindParam(6,$this->requirements);
            $stmt->bindParam(7,$this->emp_id);
             $stmt->execute();
        






        
    }

  public  function delete()
   {   
         
    $sql = "DELETE FROM `job` WHERE id = ?";
    $stmt = $this->pdo()->prepare($sql);
    $stmt->execute([$this->id]); 

    }    
    
    public  function update()
   {   
       
      /*
           $con2 = $d1->conn();
          $sql = "UPDATE `job` SET `title`=?,`desc`=?,`type`=?,`sal`=?,`date`=?, 'require' =? WHERE emp_id = '$this->emp_id'";
        //$stmt = $con2->prepare($sql);
            $stmt->bindParam(1,$this->title);
            $stmt->bindParam(2,$this->desc);
            $stmt->bindParam(3,$this->type);
            $stmt->bindParam(4,$this->date);
            $stmt->bindParam(5,$this->require);
             $stmt->execute();
      */






   }     









  }




?>