<?php
session_start();
require("fpdf.php");

$hostname = "localhost";
$db = "recruitment";
$Username = "root";
$Password = "";
$conn = mysqli_connect($hostname,$Username,$Password,$db) Or DIE ("unable to connect database");


   

if(isset($_POST['Generate'])){

    $pdf = new FPDF();

          $pdf->AddPage();
          $pdf->SetFont("Arial","B",19);
             
        if(isset($_POST['all'])){
           
          
          $sql="SELECT * FROM `application`" ;
         $result1 = $conn->query($sql);
         if ($result1->num_rows > 0) {
           while($row = $result1->fetch_assoc()) {

                $pdf->cell(70,10,"Applicant Name",1,0);
                $pdf->cell(50,10, $row['name'],1,1);

                $pdf->cell(50,10,"Status",1,0);
                $pdf->cell(50,10,$row['status'],1,1);
        
                $pdf->cell(70,10,"Application Date",1,0);
                $pdf->cell(50,10,$row['date'],1,1);

                $pdf->cell(70,10,"Job ID",1,0);
                 $pdf->cell(50,10,$row['job_id'],1,1);

              

              
                


           }}

        }

        
        

        if(isset($_POST['approve'])){
           
           
            $sql="SELECT * FROM `application`WHERE status = 'approve' ";
           $result2 = $conn->query($sql);
           if ($result2->num_rows > 0) {
             while($row = $result2->fetch_assoc()) {
  
                  $pdf->cell(70,10,"Applicant Name",1,0);
                  $pdf->cell(50,10, $row['name'],1,1);
  
                  $pdf->cell(50,10,"Status",1,0);
                  $pdf->cell(50,10,$row['status'],1,1);
          
                  $pdf->cell(70,10,"Application Date",1,0);
                  $pdf->cell(50,10,$row['date'],1,1);
  
                  $pdf->cell(70,10,"Job ID",1,0);
                   $pdf->cell(50,10,$row['job_id'],1,1);
  
                
  
                
                  
  
  
             }}
  
          }






             
        if(isset($_POST['decline'])){
           
           
            $sql="SELECT * FROM `application`WHERE status = 'decline' ";
           $result3 = $conn->query($sql);
           if ($result3->num_rows > 0) {
             while($row = $result3->fetch_assoc()) {
  
                  $pdf->cell(70,10,"Applicant Name",1,0);
                  $pdf->cell(50,10, $row['name'],1,1);
  
                  $pdf->cell(50,10,"Status",1,0);
                  $pdf->cell(50,10,$row['status'],1,1);
          
                  $pdf->cell(70,10,"Application Date",1,0);
                  $pdf->cell(50,10,$row['date'],1,1);
  
                  $pdf->cell(70,10,"Job ID",1,0);
                   $pdf->cell(50,10,$row['job_id'],1,1);
  
                
  
                
                  
  
  
             }}
  
          }
           
           

        

       


    $pdf->Output();
}










?>