
<?php
include("job_cl.php");

$hostname = "localhost";
$db = "recruitment";
$Username = "root";
$Password = "";
$conn = mysqli_connect($hostname,$Username,$Password,$db) Or DIE ("unable to connect database");
$query = "SELECT * FROM application where status ='approve'";
$result = mysqli_query($conn,$query);

?>

<!Doctype html>

<html lang = "en">
<head>
  <title> job </title>
     <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">

<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

.navbar {
  overflow: hidden;
  background-color: #333; 
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.subnav {
  float: left;
  overflow: hidden;
}

.subnav .subnavbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .subnav:hover .subnavbtn {
  background-color: red;
}

.subnav-content {
  display: none;
  position: absolute;
  left: 0;
  background-color: red;
  width: 100%;
  z-index: 1;
}

.subnav-content a {
  float: left;
  color: white;
  text-decoration: none;
}

.subnav-content a:hover {
  background-color: #eee;
  color: black;
}

.subnav:hover .subnav-content {
  display: block;
}

/* Create two equal columns that floats next to each other */
.column {
  float: left;
  width: 50%;
  padding: 10px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
/* Style the buttons */
.btn {
  border: none;
  outline: none;
  padding: 12px 16px;
  background-color: #f1f1f1;
  cursor: pointer;
}

.btn:hover {
  background-color: #ddd;
}

.btn.active {
  background-color: #666;
  color: white;
}
.cbutton{
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
}
label{

 color:red;
}

</style>
</head>

<body>

  <header>

  <div class="navbar">
  <div class="subnav">
    <button class="subnavbtn">Account<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="create.php">profile</a>
      <a href="view.php">view profile</a>
      <a href="#team">settings</a>
      <a href="logout.php">logout</a>
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn">Applications<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="candidates.php">All applications</a>
      <a href="#deliver">Approved Applications</a>
     
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn">Job<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="job.php">create post</a>
      <a href="viewjob.php">view job</a>
    </div>
  </div>
  <a href="reports.php">Reports</a>
</div>

  </header>
  <?php

while($rows = mysqli_fetch_array($result))
{

?>

<ul>
<li>
<?php echo $rows ['id']; ?><br>
<?php echo $rows ['name']; ?><br>
<?php echo $rows ['date']; ?><br> 
</li>

</ul>
</form>
<?php
}
?>

</body>




</html>