
<?php
 
 $hostname = "localhost";
 $db = "recruitment";
 $Username = "root";
 $Password = "";
 $conn = mysqli_connect($hostname,$Username,$Password,$db) Or DIE ("unable to connect database");

 $sql = "SELECT * FROM `application`";

 $result = $conn->query( $sql);

 if ($result->num_rows > 0) {
   // output data of each row
   while($rows = $result->fetch_assoc()) {
     $job_id = $rows ['job_id'];
     $candidate_id = $rows ['candidate_id'];
     $application_id =$rows ['id'];
   }
  }




  
?>







<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

/*navigation bar */

.navbar {
  overflow: hidden;
  background-color: #333; 
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.subnav {
  float: left;
  overflow: hidden;
}

.subnav .subnavbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .subnav:hover .subnavbtn {
  background-color: red;
}

.subnav-content {
  display: none;
  position: absolute;
  left: 0;
  background-color: red;
  width: 100%;
  z-index: 1;
}

.subnav-content a {
  float: left;
  color: white;
  text-decoration: none;
}

.subnav-content a:hover {
  background-color: #eee;
  color: black;
}

.subnav:hover .subnav-content {
  display: block;
}





/* The grid: Three equal columns that floats next to each other */
.column {
  float: left;
  width: 20%;
  padding: 50px;
  text-align: center;
  font-size: 15px;
  cursor: pointer;
  color: white;
}

.containerTab {
  padding: 20px;
  color: white;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Closable button inside the container tab */
.closebtn {
  float: right;
  color: white;
  font-size: 35px;
  cursor: pointer;
}
</style>
</head>
<body>

<header>
<div class="navbar">
  <div class="subnav">
    <button class="subnavbtn">Account<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="create.php">profile</a>
      <a href="view.php">view profile</a>
      <a href="#team">settings</a>
      <a href="logout.php">logout</a>
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn">Applications<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="candidates.php">All applications</a>
      <a href="approve.php">Approved Applications</a>
     
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn">Job<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="job.php">create post</a>
      <a href="viewjob.php">view job</a>
    </div>
  </div>
  <a href="reports.php">Reports</a>
</div>

</header>

<div style="text-align:left">
 
  <p>Applications:</p>
</div>

<!-- Three columns -->
<div class="row">
  <div class="column" onclick="openTab('b1');" style="background:#333;">
    Personal Information
  </div>
  <div class="column" onclick="openTab('b2');" style="background:#333;">
    Education
  </div>
  <div class="column" onclick="openTab('b3');" style="background:#333;">
   Experiance
  </div>
  <div class="column" onclick="openTab('b4');" style="background:#333;">
   Attachments 
  </div>
</div>

<!-- Full-width columns: (hidden by default) -->
<div id="b1" class="containerTab" style="display:none;background:red">
  <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
  <?php

$candidate ="SELECT * FROM `candidate` WHERE candidate_id  =  '$candidate_id'";
$result2 = $conn->query( $candidate );

 if ($result2->num_rows > 0) {
   // output data of each row
   while($row = $result2->fetch_assoc()) {

?>
   <ul>
  <li>
  <?php echo $row ['name']; ?><br>
  <?php echo $row ['last']; ?><br>
  <?php echo $row ['gender']; ?><br> 
  <?php echo $row ['email']; ?><br> 
  <?php echo $row ['phone']; ?><br> 
  </li>
  </ul>
  <?php
   }}


  ?>
</div>

<div id="b2" class="containerTab" style="display:none;background:red">
  <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
  <h2>Education</h2>
  <?php

$education ="SELECT * FROM `education`   WHERE candidate_id  =  '$candidate_id'";
$result3 = $conn->query($education);
if ($result3->num_rows > 0) {
// output data of each row
  while($row = $result3->fetch_assoc()) {

?>
<ul>
<li>
<?php echo $row ['name']; ?><br>
<?php echo $row ['institution']; ?><br>
<?php echo $row ['date']; ?><br> 
<?php echo $row ['project_name']; ?><br> 
<?php echo $row ['description']; ?><br> 
</li>
</ul>
<?php
 }
}
?>
</div>

<div id="b3" class="containerTab" style="display:none;background:red">
  <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
  <h2>Experiance</h2>
  <?php

$experiance ="SELECT * FROM `experiance`  WHERE candidate_id  =  '$candidate_id'";
 $result4 = $conn->query($experiance);
 if ($result4->num_rows > 0) {
// output data of each row
while($row = $result4->fetch_assoc()) {

 ?>
<ul>
     <li>
       <?php echo $row ['title']; ?><br>
       <?php echo $row ['name']; ?><br>
       <?php echo $row ['Sdate']; ?><br> 
       <?php echo $row ['Edate']; ?><br> 
       <?php echo $row ['description']; ?><br> 
       <?php echo $row ['achievements']; ?><br> 
     </li>
   </ul>
<?php
}}


?>

</div>


<div id="b4" class="containerTab" style="display:none;background:red">
  <span onclick="this.parentElement.style.display='none'" class="closebtn">&times;</span>
  <h2>Attachment</h2>
    
  <?php

  $attachment ="SELECT * FROM `attachment`  WHERE candidate_id  =  '$candidate_id'";
  $result5 = $conn->query($attachment);
  if ($result5 ->num_rows > 0) {
   // output data of each row
  while($row = $result5->fetch_assoc()) {

 ?>
  <ul>
     <li>
       <?php echo $row ['name']; ?><br>
       <?php echo $row ['doc']; ?><br>
     </li>
   </ul>
  <?php
   }}


  ?>
     <button name ="approve">approve</button>
    <button name ="decline">decline</button>
</div>


<script>
function openTab(tabName) {
  var i, x;
  x = document.getElementsByClassName("containerTab");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  document.getElementById(tabName).style.display = "block";
}
</script>

</body>
</html> 
