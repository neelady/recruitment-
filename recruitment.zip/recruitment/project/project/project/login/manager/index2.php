<?php
 session_start();
 $hostname = "localhost";
 $db = "recruitment";
 $Username = "root";
 $Password = "";
 $conn = mysqli_connect($hostname,$Username,$Password,$db) Or DIE ("unable to connect database");
 

 if( isset($_SESSION['userid2'] ) ) {

  $id =$_SESSION['userid2'];

}


 
?>
<!DocTYPE html>
<html>
<head>
<title> Profile Review</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link  href="style.css" rel="stylesheet" type = "text/css">

<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

.navbar {
  overflow: hidden;
  background-color: #333; 
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.subnav {
  float: left;
  overflow: hidden;
}

.subnav .subnavbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .subnav:hover .subnavbtn {
  background-color: red;
}

.subnav-content {
  display: none;
  position: absolute;
  left: 0;
  background-color: red;
  width: 100%;
  z-index: 1;
}

.subnav-content a {
  float: left;
  color: white;
  text-decoration: none;
}

.subnav-content a:hover {
  background-color: #eee;
  color: black;
}

.subnav:hover .subnav-content {
  display: block;
}

/*Table */
.row {
  display: flex;
  margin-left:-15px;
  margin-right:-15px;
}

.column {
  flex: 50%;
  padding: 5px;
}

table {
  border-collapse: collapse;
  margin: 100px;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}

th, td {
  text-align: left;
  padding: 16px;
}

tr:nth-child(even) {
  background-color: #f2f2f2;
}
.container {

    float: left;
    width: 25%;
    display:inline-block;
    background-color:red;
    color:white;
    padding: 20px;

}
</style>


</head>
<body>
<header>

<div class="navbar">
  <div class="subnav">
    <button class="subnavbtn">Account<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="create.php">profile</a>
      <a href="view.php">view profile</a>
      <a href="#team">settings</a>
      <a href="logout.php">logout</a>
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn">Applications<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="candidates.php">All applications</a>
      <a href="approve.php">Approved Applications</a>
     
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn">Job<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="job.php">create post</a>
      <a href="viewjob.php">view job</a>
    </div>
  </div>
  <a href="reports.php">Reports</a>
</div>




</header>
<main>
 

    <!-- /#page-content-wrapper -->
    <div class="row">
  <div class="column">
    <table class="table"     > 
 <thead>
 <tr>
     <th  scope="col">#</th>
     <th  scope="col">Name</th>
     <th  scope="col">Closing Dates</th>
     <th  scope="col">Status</th>
     
 </tr>
 </thead>

    <?php


 $query2 = "SELECT DISTINCT j.id AS id ,j.title AS title,a.name as name,a.date AS date,a.status AS status
  FROM job j, application a , candidate c 
  WHERE a.job_id = j.id 
  AND j.emp_id = '$id'";
 $result = mysqli_query($conn,$query2);
 while($rows = mysqli_fetch_array($result))
  {
  
?>
                                            <tbody>
                                            <tr>
                                                <td scope="row" >#<?php echo $rows['id'];?></td>
                                                <td ><?php echo $rows['title'];?></td>
                                                <td ><?php echo $rows['name'];?></td>
                                                <td ><?php echo $rows['date'];?></td>
                                                <td><?php echo  $rows['status'];?></td>
                                               
                                            </tr>
                                            <?php
                                        }
                                      ?>
                                            </tbody>
                                        </table>
                                 
</div>
</div>







                                      <?php
$sql = "SELECT Count(a.id) as num
FROM application a, job j
WHERE a.job_id=  j.id
and j.emp_id = '$id'";

$result2 = mysqli_query($conn,$sql);
 while($row= mysqli_fetch_array($result2))
  {
  
?>





      <div class="row">
                           
                                            <div class="container">
                                            Total Applications
                                            <span><?php echo $row['num'];?></span></div>
                                   
                            <?php
 }
 $sql1 = "SELECT Count(id) as number
          FROM job Where id = '$id'" ;
 $result3 = mysqli_query($conn,$sql1);
 while($row= mysqli_fetch_array($result3))
                                       
 {
?>
                            
                                         
                                            <div class="container"><span>
                                            Total jobs
                                            <?php echo $row['number'];?></span></div>
                                   
                            <?php
 }
 $sql2 = "SELECT Count(status) as status
            FROM application WHERE status = 'approved' ";
 $result4 = mysqli_query($conn,$sql2);
 while($row= mysqli_fetch_array($result4))
                                       
 {
?>
   

                           
                                           
                                        <div class="container">
                                            
                                            Total Saved jobs 
                                              <span><?php echo $row['status'];?></span></div>
                                 
                            <?php
                                        }
                                      ?>

<footer>


</footer>
</body>
</html>



