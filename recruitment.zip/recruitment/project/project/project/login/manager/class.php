<?php



class database{


 

    protected $hostname = "localhost";
    protected $db = "recruitment";
    protected $Username = "root";
    protected $Password = "";
     
      protected function conn(){
  
          $conn = mysqli_connect($this->hostname,$this->Username,$this->Password,$this->db) Or DIE ("unable to connect database");
  
  
          return $conn;
  
      }
    
  
  }

class manager extends database {
   
 
    public $name;
    public $last;
    public $position;
 
 

    public  function checkfield()
  {   
       

     if( empty($this->name)|| empty($this->last)  || empty($this->position))
     {

        return true;

     }
    
      return false;


   }

    
   public function checkname(){



    if (!preg_match("/^[a-zA-Z-' ]*$/",$this->name)) {
        return true;
      }

    return false;

   }




 }

 class company {


  public $name;
  public $location;
  public $phone;

  public  function checkfield()
  {   
       

     if( empty($this->name)|| empty($this->location)  || empty($this->phone))
     {

        return true;

     }
    
      return false;


   }



 }







?>