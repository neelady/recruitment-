
<?php
include("job_cl.php");

$hostname = "localhost";
$db = "recruitment";
$Username = "root";
$Password = "";
$conn = mysqli_connect($hostname,$Username,$Password,$db) Or DIE ("unable to connect database");
$query = "SELECT * FROM job;";
$result = mysqli_query($conn,$query);

?>



<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
* {
  box-sizing: border-box;
}
/*Navigation*/

.navbar {
  overflow: hidden;
  background-color: #333; 
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.subnav {
  float: left;
  overflow: hidden;
}

.subnav .subnavbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .subnav:hover .subnavbtn {
  background-color: red;
}

.subnav-content {
  display: none;
  position: absolute;
  left: 0;
  background-color: red;
  width: 100%;
  z-index: 1;
}

.subnav-content a {
  float: left;
  color: white;
  text-decoration: none;
}

.subnav-content a:hover {
  background-color: #eee;
  color: black;
}

.subnav:hover .subnav-content {
  display: block;
}




/* Create two equal columns that floats next to each other */
.column {
  float: left;
  width: 50%;
  padding: 10px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
/* Style the buttons */
.btn {
  border: none;
  outline: none;
  padding: 12px 16px;
  background-color: #f1f1f1;
  cursor: pointer;
}

.btn:hover {
  background-color: #ddd;
}

.btn.active {
  background-color: #666;
  color: white;
}
.cbutton{
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
}
label{

 color:red;
}
</style>
</head>
<body>
<header>

<div class="navbar">
<div class="subnav">
  <button class="subnavbtn">Account<i class="fa fa-caret-down"></i></button>
  <div class="subnav-content">
    <a href="create.php">profile</a>
    <a href="#team">update profile</a>
    <a href="#team">settings</a>
    <a href="#careers">logout</a>
  </div>
</div> 
<div class="subnav">
  <button class="subnavbtn">Applications<i class="fa fa-caret-down"></i></button>
  <div class="subnav-content">
    <a href="candidates.php">All applications</a>
    <a href="#deliver">Approved Applications</a>
   
  </div>
</div> 
<div class="subnav">
  <button class="subnavbtn">Job<i class="fa fa-caret-down"></i></button>
  <div class="subnav-content">
    <a href="job.php">create post</a>
    <a href="viewjob.php">view job</a>
  </div>
</div>
<a href="reports.php">Reports</a>
</div>

</header>




<div id="btnContainer">
  <button class="btn" onclick="listView()"><i class="fa fa-bars"></i> List</button> 
  <button class="btn active" onclick="gridView()"><i class="fa fa-th-large"></i> Grid</button>
</div>
<br>
<?php

while($rows = mysqli_fetch_array($result))
{

?>
<div class="row">
  <div class="column" style="background-color:#aaa;">
  <form action = "viewjob.php" method ="post" role = "form" >

 <h2><?php echo $rows ['title']; ?><br></h2>
 <label for="">Type</label>
<p><?php echo $rows ['type']; ?><br>
<label for="">closing</label><br>
<?php echo $rows ['date']; ?><br> 
<label for="">job description</label><br>
<?php echo $rows ['description']; ?><br>
<label for="">requirements</label> <br>
<?php echo $rows ['requirements']; ?><br> 
<label for="">Salary</label> <br>
<?php echo $rows ['salary']; ?><br>
<?php  $job_id = $rows ['id'] ; ?>
<button class="cbutton" name = "delete">delete</button></p>


</form>
  </div>
  
  <?php
}

if( isset($_POST['delete']))
{

  $job  = new job();
  $job->id  = $job_id;
  
  $job->delete();

}



?>
<script>
// Get the elements with class="column"
var elements = document.getElementsByClassName("column");

// Declare a loop variable
var i;

// List View
function listView() {
  for (i = 0; i < elements.length; i++) {
    elements[i].style.width = "100%";
  }
}

// Grid View
function gridView() {
  for (i = 0; i < elements.length; i++) {
    elements[i].style.width = "50%";
  }
}

/* Optional: Add active class to the current button (highlight it) */
var container = document.getElementById("btnContainer");
var btns = container.getElementsByClassName("btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function() {
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}
</script>

</body>
</html>
